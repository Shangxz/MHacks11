## "Left to Right" Segue

This is not real Left to Right segue, this is just a trick.

For example, we have two windows: Main and Info. And we want to segue Info window from left to right.

The main idea is to use the **standard** show segue and his invisible activate when opening the Info window. So we moving to Main window and can use **unwind segue** from left by taping the button "i".

Once again - it is just a trick, but working good!

See in action
* First example with blank views http://youtu.be/Hs_CDUJGWcM
* Second example with tableViews http://youtu.be/59-Xiol17YY
