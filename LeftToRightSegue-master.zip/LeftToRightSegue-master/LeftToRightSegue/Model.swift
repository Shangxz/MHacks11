//
//  Model.swift
//  SearchBar
//
//  Created by Shinkangsan on 12/20/16.
//  Copyright © 2016 Sheldon. All rights reserved.
//

import UIKit

class Model: NSObject {
    var imageName:String = ""
    var imageYear:String = ""
    var imageBy:String = ""
    
    init(name:String,year:String,by:String) {
        self.imageName = name
        self.imageYear = year
        self.imageBy = by
    }
    
    class func generateModelArray() -> [Model]{
        var modelAry = [Model]()
        
        modelAry.append(Model(name: "MHacks", year: "University of Michigan", by: "October 14"))
        modelAry.append(Model(name: "HackHarvard", year: "Harvard", by: "October 20"))
        modelAry.append(Model(name: "PennApps", year: "UPenn", by: "November 15"))
        modelAry.append(Model(name: "Junction Finland", year: "Junction", by: "November 23"))
        modelAry.append(Model(name: "HackPSU", year: "PSU", by: "December 3"))
        modelAry.append(Model(name: "PennApps", year: "UPenn", by: "December 15"))
        modelAry.append(Model(name: "Junction Finland", year: "Junction", by: "December 25"))
        modelAry.append(Model(name: "HackPSU", year: "PSU", by: "January 4 "))
        
        return modelAry
    }
}
