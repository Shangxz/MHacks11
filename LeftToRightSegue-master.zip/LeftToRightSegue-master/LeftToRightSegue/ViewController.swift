//
//  ViewController.swift
//  LeftToRightSegue
//
//  Created by Mathew Mozaffari on 2018-10-14.
//  Copyright © 2018 bezumkin. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBAction func buttonTap(_ sender: Any) {
        
        let progressBar = VVCircleProgressBar()
        progressBar.stopPulsingAnimation()

    }
    override func viewDidLoad() {
        super.viewDidLoad()

        let progressBar = VVCircleProgressBar()
        progressBar.center = self.view.center
        self.view.addSubview(progressBar)
        progressBar.textColor = UIColor.orange
        progressBar.font = UIFont(name: "HelveticaNeue-Bold", size: 24)!
        progressBar.pulsingColor = UIColor.orange
        progressBar.progressColor = UIColor.orange
        progressBar.trackingStrokeColor = UIColor.orange
        progressBar.trackingFillColor = UIColor.white
        // Do any additional setup after loading the view.
        
        progressBar.startPulsingAnimation()

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
        let progressBar = VVCircleProgressBar()

    }
    
    


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
