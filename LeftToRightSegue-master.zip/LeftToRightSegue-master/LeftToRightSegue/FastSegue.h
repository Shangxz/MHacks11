//
//  FastSegue.h
//  LeftToRightSegue
//
//  Created by Василий Наумкин on 03.10.14.
//  Copyright (c) 2014 bezumkin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FastSegue : UIStoryboardSegue

@end
